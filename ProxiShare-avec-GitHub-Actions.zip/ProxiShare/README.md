# ProxiShare

Application Android de proximité basée sur Bluetooth Low Energy (BLE).

## Fonctionnement
- Le bouton « Scanner » recherche uniquement les appareils qui annoncent le service ProxiShare.
- Un utilisateur peut saisir son nom et son numéro, puis activer explicitement « Partager ».
- Le téléphone annonce alors le service BLE et expose ces deux champs en lecture.
- Un autre utilisateur peut demander ces informations en se connectant au service.
- L’application ne lit pas les SMS, photos, contacts, fichiers, comptes ou autres données privées.

## Construction
Ouvrir le dossier dans Android Studio (version récente), puis Build > Build APK(s).

## Permissions
Android 12+ : Bluetooth Scan / Connect / Advertise.
Android 11 et inférieur : localisation fine pour le scan BLE.
