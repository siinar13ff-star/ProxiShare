package com.example.proxishare

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.nio.charset.StandardCharsets
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var bluetooth: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private lateinit var advertiser: BluetoothLeAdvertiser
    private lateinit var status: TextView
    private lateinit var results: LinearLayout

    private val serviceUuid = UUID.fromString("7c1d1000-8f6a-4a7b-9d6d-111111111111")
    private val nameUuid = UUID.fromString("7c1d1001-8f6a-4a7b-9d6d-111111111111")
    private val phoneUuid = UUID.fromString("7c1d1002-8f6a-4a7b-9d6d-111111111111")

    private var server: BluetoothGattServer? = null
    private var advertising = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(type: Int, result: ScanResult) {
            val device = result.device
            runOnUiThread {
                addDevice(device, result.rssi)
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "Échec du scan Bluetooth : $errorCode" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        results = findViewById(R.id.resultsContainer)

        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetooth = manager.adapter
        scanner = bluetooth.bluetoothLeScanner
        advertiser = bluetooth.bluetoothLeAdvertiser

        findViewById<Button>(R.id.scanButton).setOnClickListener {
            if (ensurePermissions()) startScan()
        }

        findViewById<Button>(R.id.shareButton).setOnClickListener {
            if (ensurePermissions()) toggleSharing()
        }
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun ensurePermissions(): Boolean {
        val missing = requiredPermissions().filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
            return false
        }
        return true
    }

    private fun startScan() {
        results.removeAllViews()
        status.text = "Recherche pendant 10 secondes…"
        scanner.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(serviceUuid)).build()),
            ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build(),
            scanCallback
        )
        Handler(Looper.getMainLooper()).postDelayed({
            scanner.stopScan(scanCallback)
            status.text = "Scan terminé."
        }, 10_000)
    }

    private fun addDevice(device: BluetoothDevice, rssi: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        val name = try { device.name ?: "Appareil ProxiShare" } catch (_: SecurityException) { "Appareil ProxiShare" }
        val title = TextView(this).apply {
            text = "$name  •  signal ${rssi} dBm"
            textSize = 17f
        }
        val button = Button(this).apply {
            text = "Demander les coordonnées partagées"
            setOnClickListener { connectAndRead(device) }
        }
        row.addView(title)
        row.addView(button)
        results.addView(row)
    }

    private fun connectAndRead(device: BluetoothDevice) {
        status.text = "Connexion pour lire les informations volontairement partagées…"
        device.connectGatt(this, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, statusCode: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) gatt.discoverServices()
                else if (newState == BluetoothProfile.STATE_DISCONNECTED) gatt.close()
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, statusCode: Int) {
                val service = gatt.getService(serviceUuid)
                val characteristic = service?.getCharacteristic(nameUuid)
                if (characteristic != null) gatt.readCharacteristic(characteristic)
            }

            override fun onCharacteristicRead(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
                if (characteristic.uuid == nameUuid) {
                    val sharedName = String(characteristic.value ?: ByteArray(0), StandardCharsets.UTF_8)
                    val phoneChar = gatt.getService(serviceUuid)?.getCharacteristic(phoneUuid)
                    if (phoneChar != null) {
                        gatt.readCharacteristic(phoneChar)
                        runOnUiThread { status.text = "Nom partagé : $sharedName" }
                    }
                } else if (characteristic.uuid == phoneUuid) {
                    val phone = String(characteristic.value ?: ByteArray(0), StandardCharsets.UTF_8)
                    runOnUiThread {
                        status.text = "Coordonnées partagées : $phone"
                        Toast.makeText(this@MainActivity, "Partage accepté par l’autre appareil.", Toast.LENGTH_LONG).show()
                    }
                    gatt.disconnect()
                    gatt.close()
                }
            }
        })
    }

    private fun toggleSharing() {
        if (advertising) {
            stopSharing()
            return
        }

        val name = findViewById<EditText>(R.id.nameInput).text.toString().trim()
        val phone = findViewById<EditText>(R.id.phoneInput).text.toString().trim()

        if (name.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Renseigne ton nom et ton numéro avant de partager.", Toast.LENGTH_LONG).show()
            return
        }

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .build()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(serviceUuid))
            .build()

        advertiser.startAdvertising(settings, data, advertiseCallback)
        startGattServer(name, phone)
    }

    private fun startGattServer(name: String, phone: String) {
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        server = manager.openGattServer(this, object : BluetoothGattServerCallback() {})
        val service = BluetoothGattService(serviceUuid, BluetoothGattService.SERVICE_TYPE_PRIMARY)

        service.addCharacteristic(BluetoothGattCharacteristic(
            nameUuid,
            BluetoothGattCharacteristic.PROPERTY_READ,
            BluetoothGattCharacteristic.PERMISSION_READ
        ).apply { value = name.toByteArray(StandardCharsets.UTF_8) })

        service.addCharacteristic(BluetoothGattCharacteristic(
            phoneUuid,
            BluetoothGattCharacteristic.PROPERTY_READ,
            BluetoothGattCharacteristic.PERMISSION_READ
        ).apply { value = phone.toByteArray(StandardCharsets.UTF_8) })

        server?.addService(service)
        advertising = true
        findViewById<Button>(R.id.shareButton).text = "Arrêter le partage"
        status.text = "Partage actif : les coordonnées sont lisibles par les appareils qui se connectent."
    }

    private fun stopSharing() {
        advertiser.stopAdvertising(advertiseCallback)
        server?.close()
        server = null
        advertising = false
        findViewById<Button>(R.id.shareButton).text = "Partager mon nom et mon numéro"
        status.text = "Partage arrêté."
    }

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {}
        override fun onStartFailure(errorCode: Int) {
            runOnUiThread { status.text = "Impossible d’activer le partage Bluetooth : $errorCode" }
        }
    }

    override fun onDestroy() {
        try { scanner.stopScan(scanCallback) } catch (_: Exception) {}
        if (advertising) stopSharing()
        super.onDestroy()
    }
}
